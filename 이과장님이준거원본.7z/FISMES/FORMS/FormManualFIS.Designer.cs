﻿namespace FISMES.FORMS
{
    partial class FormManualFIS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
            "->",
            "2016-04-04 12:23:57",
            "asdf"}, -1);
            this.listViewFIS = new System.Windows.Forms.ListView();
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxDateF1 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.buttonSendF2 = new System.Windows.Forms.Button();
            this.comboBoxResultF2 = new System.Windows.Forms.ComboBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBoxResultF3 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxDateF3 = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.buttonSendF4 = new System.Windows.Forms.Button();
            this.comboBoxResultF4 = new System.Windows.Forms.ComboBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBoxAlarmCode = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxAlarmStatus = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxCoatingAmountF3 = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // listViewFIS
            // 
            this.listViewFIS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.listViewFIS.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9});
            this.listViewFIS.ForeColor = System.Drawing.Color.White;
            this.listViewFIS.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listViewFIS.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem2});
            this.listViewFIS.Location = new System.Drawing.Point(12, 12);
            this.listViewFIS.Name = "listViewFIS";
            this.listViewFIS.Size = new System.Drawing.Size(984, 416);
            this.listViewFIS.TabIndex = 16;
            this.listViewFIS.UseCompatibleStateImageBehavior = false;
            this.listViewFIS.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "";
            this.columnHeader7.Width = 30;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Date";
            this.columnHeader8.Width = 120;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Contents";
            this.columnHeader9.Width = 812;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxDateF1);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Location = new System.Drawing.Point(12, 434);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(239, 55);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " F1 [Receive] ";
            // 
            // textBoxDateF1
            // 
            this.textBoxDateF1.Location = new System.Drawing.Point(83, 21);
            this.textBoxDateF1.Name = "textBoxDateF1";
            this.textBoxDateF1.ReadOnly = true;
            this.textBoxDateF1.Size = new System.Drawing.Size(150, 21);
            this.textBoxDateF1.TabIndex = 19;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.label2);
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(6, 21);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(77, 21);
            this.panel2.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 21);
            this.label2.TabIndex = 0;
            this.label2.Text = "Last Date";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.buttonSendF2);
            this.groupBox3.Controls.Add(this.comboBoxResultF2);
            this.groupBox3.Controls.Add(this.panel5);
            this.groupBox3.Location = new System.Drawing.Point(12, 495);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(239, 85);
            this.groupBox3.TabIndex = 27;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = " F2 [Send] ";
            // 
            // buttonSendF2
            // 
            this.buttonSendF2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonSendF2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSendF2.ForeColor = System.Drawing.Color.White;
            this.buttonSendF2.Location = new System.Drawing.Point(6, 47);
            this.buttonSendF2.Name = "buttonSendF2";
            this.buttonSendF2.Size = new System.Drawing.Size(227, 30);
            this.buttonSendF2.TabIndex = 28;
            this.buttonSendF2.Text = "Send F2";
            this.buttonSendF2.UseVisualStyleBackColor = false;
            this.buttonSendF2.Click += new System.EventHandler(this.buttonSendF2_Click);
            // 
            // comboBoxResultF2
            // 
            this.comboBoxResultF2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxResultF2.FormattingEnabled = true;
            this.comboBoxResultF2.Items.AddRange(new object[] {
            "OK",
            "NG"});
            this.comboBoxResultF2.Location = new System.Drawing.Point(83, 20);
            this.comboBoxResultF2.Name = "comboBoxResultF2";
            this.comboBoxResultF2.Size = new System.Drawing.Size(150, 20);
            this.comboBoxResultF2.TabIndex = 27;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel5.Controls.Add(this.label5);
            this.panel5.ForeColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(6, 20);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(77, 21);
            this.panel5.TabIndex = 26;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 21);
            this.label5.TabIndex = 0;
            this.label5.Text = "Result";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBoxCoatingAmountF3);
            this.groupBox4.Controls.Add(this.panel8);
            this.groupBox4.Controls.Add(this.textBoxResultF3);
            this.groupBox4.Controls.Add(this.panel1);
            this.groupBox4.Controls.Add(this.textBoxDateF3);
            this.groupBox4.Controls.Add(this.panel7);
            this.groupBox4.Location = new System.Drawing.Point(257, 435);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(239, 104);
            this.groupBox4.TabIndex = 28;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = " F3 [Receive] ";
            // 
            // textBoxResultF3
            // 
            this.textBoxResultF3.Location = new System.Drawing.Point(81, 48);
            this.textBoxResultF3.Name = "textBoxResultF3";
            this.textBoxResultF3.ReadOnly = true;
            this.textBoxResultF3.Size = new System.Drawing.Size(150, 21);
            this.textBoxResultF3.TabIndex = 29;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(6, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(77, 21);
            this.panel1.TabIndex = 28;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Result";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxDateF3
            // 
            this.textBoxDateF3.Location = new System.Drawing.Point(83, 21);
            this.textBoxDateF3.Name = "textBoxDateF3";
            this.textBoxDateF3.ReadOnly = true;
            this.textBoxDateF3.Size = new System.Drawing.Size(150, 21);
            this.textBoxDateF3.TabIndex = 19;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel7.Controls.Add(this.label7);
            this.panel7.ForeColor = System.Drawing.Color.White;
            this.panel7.Location = new System.Drawing.Point(6, 21);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(77, 21);
            this.panel7.TabIndex = 18;
            // 
            // label7
            // 
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 21);
            this.label7.TabIndex = 0;
            this.label7.Text = "Last Date";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.buttonSendF4);
            this.groupBox7.Controls.Add(this.comboBoxResultF4);
            this.groupBox7.Controls.Add(this.panel6);
            this.groupBox7.Location = new System.Drawing.Point(502, 435);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(239, 85);
            this.groupBox7.TabIndex = 29;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = " F4 [Send] ";
            // 
            // buttonSendF4
            // 
            this.buttonSendF4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonSendF4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSendF4.ForeColor = System.Drawing.Color.White;
            this.buttonSendF4.Location = new System.Drawing.Point(6, 48);
            this.buttonSendF4.Name = "buttonSendF4";
            this.buttonSendF4.Size = new System.Drawing.Size(221, 30);
            this.buttonSendF4.TabIndex = 25;
            this.buttonSendF4.Text = "Send F4";
            this.buttonSendF4.UseVisualStyleBackColor = false;
            this.buttonSendF4.Click += new System.EventHandler(this.buttonSendF4_Click);
            // 
            // comboBoxResultF4
            // 
            this.comboBoxResultF4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxResultF4.FormattingEnabled = true;
            this.comboBoxResultF4.Items.AddRange(new object[] {
            "OK",
            "NG"});
            this.comboBoxResultF4.Location = new System.Drawing.Point(83, 21);
            this.comboBoxResultF4.Name = "comboBoxResultF4";
            this.comboBoxResultF4.Size = new System.Drawing.Size(144, 20);
            this.comboBoxResultF4.TabIndex = 24;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel6.Controls.Add(this.label6);
            this.panel6.ForeColor = System.Drawing.Color.White;
            this.panel6.Location = new System.Drawing.Point(6, 21);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(77, 21);
            this.panel6.TabIndex = 23;
            // 
            // label6
            // 
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 21);
            this.label6.TabIndex = 0;
            this.label6.Text = "Result";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBoxAlarmCode);
            this.groupBox2.Controls.Add(this.panel4);
            this.groupBox2.Controls.Add(this.textBoxAlarmStatus);
            this.groupBox2.Controls.Add(this.panel3);
            this.groupBox2.Location = new System.Drawing.Point(747, 435);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(239, 85);
            this.groupBox2.TabIndex = 30;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = " FA [Receive] ";
            // 
            // textBoxAlarmCode
            // 
            this.textBoxAlarmCode.Location = new System.Drawing.Point(83, 48);
            this.textBoxAlarmCode.Name = "textBoxAlarmCode";
            this.textBoxAlarmCode.ReadOnly = true;
            this.textBoxAlarmCode.Size = new System.Drawing.Size(150, 21);
            this.textBoxAlarmCode.TabIndex = 32;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel4.Controls.Add(this.label4);
            this.panel4.ForeColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(6, 48);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(77, 21);
            this.panel4.TabIndex = 31;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 21);
            this.label4.TabIndex = 0;
            this.label4.Text = "Alarm Code";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxAlarmStatus
            // 
            this.textBoxAlarmStatus.Location = new System.Drawing.Point(83, 21);
            this.textBoxAlarmStatus.Name = "textBoxAlarmStatus";
            this.textBoxAlarmStatus.ReadOnly = true;
            this.textBoxAlarmStatus.Size = new System.Drawing.Size(150, 21);
            this.textBoxAlarmStatus.TabIndex = 30;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.label3);
            this.panel3.ForeColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(6, 21);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(77, 21);
            this.panel3.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 21);
            this.label3.TabIndex = 0;
            this.label3.Text = "Alarm Status";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxCoatingAmountF3
            // 
            this.textBoxCoatingAmountF3.Location = new System.Drawing.Point(81, 75);
            this.textBoxCoatingAmountF3.Name = "textBoxCoatingAmountF3";
            this.textBoxCoatingAmountF3.ReadOnly = true;
            this.textBoxCoatingAmountF3.Size = new System.Drawing.Size(150, 21);
            this.textBoxCoatingAmountF3.TabIndex = 31;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel8.Controls.Add(this.label8);
            this.panel8.ForeColor = System.Drawing.Color.White;
            this.panel8.Location = new System.Drawing.Point(6, 75);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(77, 21);
            this.panel8.TabIndex = 30;
            // 
            // label8
            // 
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(0, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 21);
            this.label8.TabIndex = 0;
            this.label8.Text = "Amount";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormManualFIS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1008, 586);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.listViewFIS);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormManualFIS";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "FormManualFIS";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormManualFIS_FormClosing);
            this.Load += new System.EventHandler(this.FormManualFIS_Load);
            this.VisibleChanged += new System.EventHandler(this.FormManualFIS_VisibleChanged);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView listViewFIS;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxDateF1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button buttonSendF2;
        private System.Windows.Forms.ComboBox comboBoxResultF2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBoxResultF3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxDateF3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button buttonSendF4;
        private System.Windows.Forms.ComboBox comboBoxResultF4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxAlarmCode;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxAlarmStatus;
        private System.Windows.Forms.TextBox textBoxCoatingAmountF3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label8;
    }
}