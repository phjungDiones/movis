﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FISMES.FORMS.POPUP
{
    public partial class FormPopupSetting : Form
    {
        public FormPopupSetting()
        {
            InitializeComponent();
        }
    }
}
