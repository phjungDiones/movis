﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FISMES.GLOBAL
{
    public class MachineStatus
    {
        public static bool AUTO_MODE
        {
            get;
            set;
        }
    }
}
